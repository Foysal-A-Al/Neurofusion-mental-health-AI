from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score, brier_score_loss
from sklearn.model_selection import train_test_split
from .features import NUMERIC_FEATURES, CATEGORICAL_FEATURES, FEATURE_COLUMNS


@dataclass
class TrainingResult:
    state_model: Pipeline
    risk_model: Pipeline
    metrics: dict
    test_patient_ids: list[str]


def build_pipeline(multiclass: bool = False) -> Pipeline:
    preprocessor = ColumnTransformer([
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), NUMERIC_FEATURES),
        ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), CATEGORICAL_FEATURES),
    ])
    base = LogisticRegression(max_iter=2500, class_weight="balanced", random_state=42)
    calibrated = CalibratedClassifierCV(base, method="sigmoid", cv=3)
    return Pipeline([("preprocess", preprocessor), ("model", calibrated)])


def train_models(features: pd.DataFrame, test_size: float = 0.2, seed: int = 42) -> TrainingResult:
    idx_train, idx_test = train_test_split(
        np.arange(len(features)), test_size=test_size, random_state=seed,
        stratify=features["mood_state"]
    )
    train, test = features.iloc[idx_train], features.iloc[idx_test]
    X_train, X_test = train[FEATURE_COLUMNS], test[FEATURE_COLUMNS]

    state_model = build_pipeline(multiclass=True)
    risk_model = build_pipeline(multiclass=False)
    state_model.fit(X_train, train["mood_state"])
    risk_model.fit(X_train, train["deterioration_7d"])

    state_pred = state_model.predict(X_test)
    risk_pred = risk_model.predict(X_test)
    risk_prob = risk_model.predict_proba(X_test)[:, 1]
    metrics = {
        "state_accuracy": float(accuracy_score(test["mood_state"], state_pred)),
        "state_balanced_accuracy": float(balanced_accuracy_score(test["mood_state"], state_pred)),
        "state_macro_f1": float(f1_score(test["mood_state"], state_pred, average="macro")),
        "risk_accuracy": float(accuracy_score(test["deterioration_7d"], risk_pred)),
        "risk_f1": float(f1_score(test["deterioration_7d"], risk_pred, zero_division=0)),
        "risk_roc_auc": float(roc_auc_score(test["deterioration_7d"], risk_prob)),
        "risk_brier": float(brier_score_loss(test["deterioration_7d"], risk_prob)),
        "n_train": int(len(train)), "n_test": int(len(test))
    }
    return TrainingResult(state_model, risk_model, metrics, test["patient_id"].tolist())
