from __future__ import annotations
import pandas as pd

REQUIRED_COLUMNS = {
    "patient_id", "date", "age", "sex", "mood_score", "sleep_hours",
    "stress_level", "activity_minutes", "medication_adherence",
    "speech_rate", "pause_ratio", "sentiment_score", "mood_state",
    "deterioration_7d"
}


def validate_longitudinal_frame(df: pd.DataFrame) -> None:
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("Dataset is empty")
    if df["patient_id"].isna().any():
        raise ValueError("patient_id contains missing values")
    if not df["mood_state"].isin(["depressive", "stable", "elevated"]).all():
        raise ValueError("mood_state contains invalid labels")
    bounded = {
        "mood_score": (0, 10), "sleep_hours": (0, 24), "stress_level": (0, 10),
        "medication_adherence": (0, 1), "pause_ratio": (0, 1), "sentiment_score": (-1, 1)
    }
    for col, (lo, hi) in bounded.items():
        if not df[col].between(lo, hi).all():
            raise ValueError(f"{col} contains values outside [{lo}, {hi}]")
