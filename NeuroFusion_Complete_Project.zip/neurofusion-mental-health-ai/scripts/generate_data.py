from __future__ import annotations
import argparse
from pathlib import Path
from neurofusion.data.synthetic import generate_longitudinal_data
from neurofusion.data.validation import validate_longitudinal_frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--patients", type=int, default=800)
    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="data/synthetic/longitudinal.csv")
    args = parser.parse_args()
    df = generate_longitudinal_data(args.patients, args.days, args.seed)
    validate_longitudinal_frame(df)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Saved {len(df):,} rows for {df.patient_id.nunique():,} patients to {out}")

if __name__ == "__main__":
    main()
