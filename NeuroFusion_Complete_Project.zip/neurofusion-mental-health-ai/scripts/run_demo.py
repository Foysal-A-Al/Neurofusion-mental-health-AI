from pathlib import Path
import json
import subprocess
import sys

from neurofusion.inference import NeuroFusionPredictor

subprocess.run([sys.executable, "scripts/generate_data.py", "--patients", "300", "--days", "21"], check=True)
subprocess.run([sys.executable, "scripts/train.py"], check=True)
example = json.loads(Path("examples/prediction_request.json").read_text())
print(json.dumps(NeuroFusionPredictor().predict(example["observations"]), indent=2))
