from __future__ import annotations
from pathlib import Path
import json
import joblib
import pandas as pd
from neurofusion.data.validation import validate_longitudinal_frame
from neurofusion.features import aggregate_patient_features
from neurofusion.modeling import train_models


def main() -> None:
    data_path = Path("data/synthetic/longitudinal.csv")
    if not data_path.exists():
        raise FileNotFoundError("Run python scripts/generate_data.py first")
    raw = pd.read_csv(data_path)
    validate_longitudinal_frame(raw)
    features = aggregate_patient_features(raw)
    result = train_models(features)
    artifact_dir = Path("artifacts")
    artifact_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(result.state_model, artifact_dir / "state_model.joblib")
    joblib.dump(result.risk_model, artifact_dir / "risk_model.joblib")
    (artifact_dir / "metrics.json").write_text(json.dumps(result.metrics, indent=2), encoding="utf-8")
    (artifact_dir / "test_patients.json").write_text(json.dumps(result.test_patient_ids, indent=2), encoding="utf-8")
    features.to_csv("data/processed/patient_features.csv", index=False)
    print(json.dumps(result.metrics, indent=2))

if __name__ == "__main__":
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    main()
