# Data Card

The included generator creates synthetic patient-level longitudinal observations. It models relationships among sleep, stress, activity, adherence, speech-derived features, mood state, and probabilistic future risk. No real patient records are distributed.

Synthetic generation can introduce unrealistic assumptions and hidden shortcuts. Results must not be generalized to clinical populations.
