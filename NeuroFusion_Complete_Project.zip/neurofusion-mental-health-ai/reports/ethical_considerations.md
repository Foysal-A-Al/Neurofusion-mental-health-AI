# Ethical Considerations

Mental-health prediction is sensitive and can cause harm through false reassurance, stigma, surveillance, or inappropriate intervention. This project therefore includes explicit research-only notices, probability calibration, uncertainty intervals, and abstention logic. Real-world use would require clinical validation, informed consent, privacy protection, security review, subgroup analysis, human oversight, regulatory assessment, and an emergency escalation policy designed by qualified professionals.
