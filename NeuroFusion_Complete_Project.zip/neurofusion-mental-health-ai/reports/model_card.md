# Model Card

## Intended use
Research and education concerning longitudinal multimodal modelling, calibration, uncertainty, and explainability.

## Out-of-scope use
Diagnosis, treatment selection, emergency assessment, autonomous clinical decisions, insurance, employment, or access control.

## Models
Two calibrated logistic-regression pipelines: multiclass mood-state classification and binary seven-day deterioration-risk estimation.

## Evaluation
Patient-level hold-out evaluation reports accuracy, balanced accuracy, macro F1, ROC-AUC, and Brier score.

## Major limitations
The data are synthetic. Metrics demonstrate software operation, not clinical validity.
