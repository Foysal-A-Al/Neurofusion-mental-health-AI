from __future__ import annotations
from datetime import date
from pydantic import BaseModel, Field


class Observation(BaseModel):
    patient_id: str = "API-PATIENT"
    date: date
    age: int = Field(ge=18, le=100)
    sex: str
    baseline_sleep: float = Field(gt=0, le=16)
    mood_score: float = Field(ge=0, le=10)
    sleep_hours: float = Field(ge=0, le=24)
    stress_level: float = Field(ge=0, le=10)
    activity_minutes: float = Field(ge=0, le=500)
    medication_adherence: float = Field(ge=0, le=1)
    speech_rate: float = Field(ge=40, le=300)
    pause_ratio: float = Field(ge=0, le=1)
    sentiment_score: float = Field(ge=-1, le=1)


class PredictionRequest(BaseModel):
    observations: list[Observation] = Field(min_length=3, max_length=60)
