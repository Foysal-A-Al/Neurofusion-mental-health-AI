from __future__ import annotations
from pathlib import Path
from fastapi import FastAPI, HTTPException
from api.schemas import PredictionRequest
from neurofusion.inference import NeuroFusionPredictor

app = FastAPI(title="NeuroFusion API", version="1.0.0", description="Research-only multimodal mental-health AI prototype")
_predictor = None


def get_predictor():
    global _predictor
    if _predictor is None:
        try:
            _predictor = NeuroFusionPredictor(Path("artifacts"))
        except FileNotFoundError as exc:
            raise HTTPException(status_code=503, detail="Models are not trained. Run scripts/generate_data.py and scripts/train.py") from exc
    return _predictor


@app.get("/health")
def health():
    return {"status": "ok", "models_available": Path("artifacts/state_model.joblib").exists()}


@app.post("/api/v1/predict")
def predict(request: PredictionRequest):
    records = [o.model_dump(mode="json") for o in request.observations]
    return get_predictor().predict(records)
